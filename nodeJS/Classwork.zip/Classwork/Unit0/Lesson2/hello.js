"use strict";

console.log("hello universe");
